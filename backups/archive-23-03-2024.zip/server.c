#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define IP "127.0.0.1"
#define PORT 33333
#define PORT_HTTP 80

//handle erros
void error(char *message) {
    fprintf(stderr, "%s: %s\n", message, strerror(errno));
    exit(EXIT_FAILURE);
}

int http_listener(int http_listener_socket);
char *http_transfer(int http_listener_accept, char *task);

int main() {
    int session = 0;
    //socket
    printf("Initializing socket...\n");
    int inferno_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (inferno_socket == -1)
        error("Socket creation failed");

    struct sockaddr_in c2_address;
    memset(&c2_address, 0, sizeof(c2_address));
    c2_address.sin_family = AF_INET;
    c2_address.sin_port = htons(PORT);
    c2_address.sin_addr.s_addr = inet_addr(IP);
    
    //http socket
    int http_listener_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    //bind
    printf("Binding socket to c2 address...\n");
    int inferno_bind = bind(inferno_socket, (struct sockaddr *) &c2_address, sizeof(c2_address));
    if (inferno_bind == -1) 
        error("Binding socket failed");

    //listen
    printf("Listening to %s:%d\n", IP, PORT);
    int inferno_listen = listen(inferno_socket, 0);
    if (inferno_listen == -1) 
        error("Listening failed");

    while (1) {
        //accept
        printf("Accepting...\n");
        int inferno_accept = accept(inferno_socket, NULL, NULL);
        if (inferno_accept == -1)
            error("Accepting failed");
        
        while (1) {
            //receive from client
            char input[1024];
            printf("Received %s\n", input);
            int inferno_receive = recv(inferno_accept, input, sizeof(input), 0);
            if (inferno_receive == 0) {
                 printf("Socket closed by peer\n");
                 break;
            }

            char *status;
            int http_listener_accept;
            char *executed;

            if (strcmp(input, "http") == 0) {
                puts("Preparing HTTP listener");
                //no come back to server until command
                http_listener_accept = http_listener(http_listener_socket);
                status = "ok";
                //send status to client
                printf("Sending: %s to client\n", status);
                send(inferno_accept, status, sizeof(status), 0);
                printf("Sent\n");

            }
            if (strcmp(input, "ok") == 0) {
                puts("Session started\n");
                session = 1;
            }

            while (session >= 1) {
                puts("sessoin is 2");
                recv(inferno_accept, input, sizeof(input), 0);
                executed = http_transfer(http_listener_accept, input);
                printf("Executed is: %s\n", executed);
                send(inferno_accept, executed, sizeof(executed), 0);
            }
            session++;

            //send to client
            printf("Sending to client: %s to client\n", input);
            send(inferno_accept, input, sizeof(input), 0);
            printf("Sent\n");

            printf("===========session %d=========", session);
        }

        //close accept
        close(inferno_accept);

    }

        //close
        printf("Closing socket...\n");
        if (close(inferno_socket) == -1)
            error("Failed closing socket");
}

int http_listener(int http_listener_socket) {

    //socket http
    printf("Initializing http listener...\n");

    struct sockaddr_in http_listener_address;
    memset(&http_listener_address, 0, sizeof(http_listener_address));
    http_listener_address.sin_family = AF_INET;
    http_listener_address.sin_port = htons(PORT_HTTP);
    http_listener_address.sin_addr.s_addr = inet_addr(IP);
    printf("HTTP listener initialized\n");
    
    //bind
    printf("Binding http listener...\n");
    int http_listener_bind = bind(http_listener_socket, (struct sockaddr *) &http_listener_address, sizeof(http_listener_address));

    //listen
    printf("Listening...\n");
    int http_listener_listen = listen(http_listener_socket, 0);

    //accept
    printf("Accepting...\n");
    int http_listener_accept = accept(http_listener_socket, NULL, NULL);
    
    printf("Ok...\n");
    return http_listener_accept;
}

char *http_transfer(int http_listener_accept, char *task) {
     //sending task to client
     printf("Inside http transfer function sending: %s\n", task);
     send(http_listener_accept, task, 1024, 0);
     //receiving client execution
     char *executed;
     recv(http_listener_accept, executed, sizeof(executed), 0);
     //return client execution
     printf("==============Returning: %s============\n", executed);
     return executed;
}
