struct http_session {
    int id;
    char protocol[20];
    char address[20];
    int port;
};

int main() {
        pid_t tcp_child_pid = fork();
        if (tcp_child_pid == 0) {
        //inside tcp_child
                    pid_t http_child_pid = fork();
                    if (http_child_pid == 0) {
                                //inside http_child
                                /*==========PROCESS HTTP==========*/
                                // i modify structure there
                    } else {
                        //inside http_parent
                    }
        //trying access structure modified inside HTTP there in TCP
        } else {
            //inside tcp_parent
        }
}
