#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#define IP "127.0.0.1"
#define PORT_TCP 33333
#define MAX_CLIENTS 10

void error(char *message) {
    fprintf(stderr, "%s: %s\n", message, strerror(errno));
    exit(EXIT_FAILURE);
}

void *handle_client(void *arg);

int main() {
    puts("Initializing socket...");
    int tcp_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (tcp_socket == -1)
        error("Socket creation failed");

    struct sockaddr_in tcp_address;
    memset(&tcp_address, 0, sizeof(tcp_address));
    tcp_address.sin_family = AF_INET;
    tcp_address.sin_port = htons(PORT_TCP);
    tcp_address.sin_addr.s_addr = inet_addr(IP);

    int reuse_tcp = 1;
    if (setsockopt(tcp_socket, SOL_SOCKET, SO_REUSEADDR, &reuse_tcp, sizeof(reuse_tcp)) == -1)
        error("Error reusing tcp address");

    if (setsockopt(tcp_socket, SOL_SOCKET, SO_REUSEPORT, &reuse_tcp, sizeof(reuse_tcp)) == -1)
        perror("Error reusing tcp port");

    puts("Binding socket to Inferno address...");
    if (bind(tcp_socket, (struct sockaddr *) &tcp_address, sizeof(tcp_address)) == -1)
        error("Binding socket failed");

    printf("Listening to %s:%d\n", IP, PORT_TCP);
    if (listen(tcp_socket, 0) == -1)
        error("Listening failed");

    while (1) {
        int tcp_accept = accept(tcp_socket, NULL, NULL);
        if (tcp_accept == -1)
            error("Error accepting tcp");
        puts("Accepted");

        pthread_t tid;
        if (pthread_create(&tid, NULL, handle_client, (void *)&tcp_accept) != 0) {
            perror("Thread creation failed");
            close(tcp_accept);
        }
    }

    close(tcp_socket);
    return 0;
}

void *handle_client(void *arg) {
    int client_socket = *((int *)arg);
    char tcp_request[1024];

    while (1) {
        ssize_t bytes_received = recv(client_socket, tcp_request, sizeof(tcp_request), 0);
        if (bytes_received == -1) {
            error("Error receiving from client");
            break;
        } else if (bytes_received == 0) {
            printf("Client closed the connection\n");
            break;
        }

        printf("Receiving from client: %.*s\n", (int)bytes_received, tcp_request);

        char tcp_response[1024] = "HELLO FROM TCP";
        printf("Sending to client: %s\n", tcp_response);
        if (send(client_socket, tcp_response, strlen(tcp_response), 0) == -1) {
            error("Error sending to client");
            break;
        }
    }

    close(client_socket);
    pthread_exit(NULL);
}
