#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define IP "127.0.0.1"
#define TCP_PORT 33333

void error(char *message) {
    fprintf(stderr, "%s: %s\n", message, strerror(errno));
    exit(EXIT_FAILURE);
}

int main() {
    // Initializing socket
    int tcp_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (tcp_socket == -1)
        error("Socket creation failed");

    // Preparing address TCP
    struct sockaddr_in tcp_address;
    memset(&tcp_address, 0, sizeof(tcp_address));
    tcp_address.sin_family = AF_INET;
    tcp_address.sin_port = htons(TCP_PORT);
    tcp_address.sin_addr.s_addr = inet_addr(IP);

    // Connect TCP
    if (connect(tcp_socket, (struct sockaddr *)&tcp_address, sizeof(tcp_address)) == -1)
        error("Connection failed");

    printf("Connected to server\n");

    // Main loop for communication with the server
    while (1) {
        char message[1024];
        printf("Enter message to send (type 'exit' to quit): ");
        fgets(message, sizeof(message), stdin);
        // Remove newline character from input
        message[strcspn(message, "\n")] = 0;

        // Send message to server
        ssize_t bytes_sent = send(tcp_socket, message, strlen(message), 0);
        if (bytes_sent == -1)
            error("Error sending message");

        if (strcmp(message, "exit") == 0) {
            printf("Exiting...\n");
            break;
        }

        // Receive response from server
        char response[1024];
        ssize_t bytes_received = recv(tcp_socket, response, sizeof(response), 0);
        if (bytes_received == -1)
            error("Error receiving response");
        else if (bytes_received == 0) {
            printf("Server closed the connection\n");
            break;
        }

        // Null-terminate the received data
        response[bytes_received] = '\0';
        printf("Server response: %s\n", response);
    }

    // Close the socket
    close(tcp_socket);

    return 0;
}
