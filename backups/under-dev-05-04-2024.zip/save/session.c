#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#define IP "127.0.0.1"
#define TCP_PORT 33333
#define MAX_LISTENERS 10
#define MAX_SESSIONS 10

struct http_listener {
    int id;
    char protocol[20];
    char address[20];
    int port;
};

struct http_session {
    int id;
    char protocol[20];
    char address[20];
    int port;
    //char username[20];
    //char hostname[20];
};

struct tcp_thread_args {
    struct http_session *session;
    int tcp_accept;
    int session_id;
    int session_num;
};

struct accept_http_thread_args {
    struct http_listener *listener;
    struct http_session *session;
    int http_socket;
    int session_id;
    int session_num;
    int listener_num;
};

//handle erros
void error(char *message) {
    fprintf(stderr, "%s: %s\n", message, strerror(errno));
    exit(EXIT_FAILURE);
}

void *tcp_thread(void *args);

void *accept_http_thread(void *args);

void *process_http_thread(void *args);

void craft_http_listener(char *request, struct http_listener *listener, int listener_id, int listener_num);

int start_http_listener(struct http_listener *listener);

void craft_http_session(struct http_listener *listener, struct http_session *session, int session_id, int session_num);

int main() {
    //struct http_listener listener[MAX_LISTENERS] = {0};
    struct http_session session[MAX_SESSIONS] = {0};
    int session_id = 1;
    int session_num = 0;

    struct tcp_thread_args args;

    //socket tcp
    puts("Initializing socket...");
    int tcp_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (tcp_socket == -1)
        error("Socket creation failed");

    //preparing address tcp
    struct sockaddr_in tcp_address;
    memset(&tcp_address, 0, sizeof(tcp_address));
    tcp_address.sin_family = AF_INET;
    tcp_address.sin_port = htons(TCP_PORT);
    tcp_address.sin_addr.s_addr = inet_addr(IP);

    int tcp_reuse = 1;
    //reuse address tcp
    if (setsockopt(tcp_socket, SOL_SOCKET, SO_REUSEADDR, &tcp_reuse, sizeof(tcp_reuse)) == -1)
        error("Error reusing tcp address");

    //reuse port tcp
    if (setsockopt(tcp_socket, SOL_SOCKET, SO_REUSEPORT, &tcp_reuse, sizeof(tcp_reuse)) == -1)
        perror("Error reusing tcp port");

    //bind tcp
    puts("Binding socket to Inferno address...");
    if (bind(tcp_socket, (struct sockaddr *) &tcp_address, sizeof(tcp_address)) == -1)
        error("Binding socket failed");

    //listen tcp
    printf("Listening to %s:%d\n", IP, TCP_PORT);
    if (listen(tcp_socket, 0) == -1)
        error("Listening failed");

    while(1) {
        //accept tcp
        puts("Accepting...");
        int tcp_accept = accept(tcp_socket, NULL, NULL);
        if (tcp_accept == -1)
            error("Accepting failed");
        puts("Client connected");

        args.session = session;
        args.tcp_accept = tcp_accept;
        args.session_num = session_num;
        args.session_id = session_id;
        pthread_t thread_tcp;
        pthread_create(&thread_tcp, NULL, tcp_thread, (void *)&args);
    }
    close(tcp_socket);
}

void *tcp_thread(void *args) {
    struct http_listener listener[MAX_LISTENERS] = {0};
    struct accept_http_thread_args http_args;
    int listener_id = 1;
    int listener_num = 0;

    struct tcp_thread_args *targs = (struct tcp_thread_args *)args;
    struct http_session *session = targs->session;
    int tcp_accept = targs->tcp_accept;
    int session_id = targs->session_id;
    int session_num = targs->session_num;

    while(1) {
        //read request
        char request[1024];
        if (recv(tcp_accept, request, sizeof(request), 0) == -1)
            error("Error receiving request");

        //watch for listeners
        if (strncmp(request, "http ", 5) == 0) {
            if (listener_id == MAX_LISTENERS)
                printf("Sorry no more than %s listeners allowed", MAX_LISTENERS);
            craft_http_listener(request, &listener[listener_num], listener_id, listener_num);
            int http_socket = start_http_listener(&listener[listener_num]); 
            listener_id++;
            listener_num++;

            http_args.session = session;
            http_args.listener = listener;
            http_args.http_socket = http_socket;
            http_args.session_num = session_num;
            http_args.session_id = session_id;
            http_args.listener_num = listener_num;

            pthread_t thread_http;
            pthread_create(&thread_http, NULL, accept_http_thread, (void *)&http_args);
        }

        char response[1024] = "HTTP/1.0 200 OK\r\n\r\n";

        if (strcmp(request, "listeners") == 0) {
            char listeners[1024];
            sprintf(listeners, "ID\tPROTOCOL\tADDRESS\tPORT\n");
            sprintf(listeners + strlen(listeners), "==\t========\t=======\t====\n");
            for (int i = 0; i < listener_num; i++) {
                sprintf(listeners + strlen(listeners), "%d\t%s\t\t%s\t%d\n", listener[i].id, listener[i].protocol, listener[i].address, listener[i].port);
            }
            strcpy(response, listeners);
        }

        else if (strcmp(request, "sessions") == 0) {
            char sessions[1024];
            sprintf(sessions, "ID\tCOMMUNICATION\tREMOTE ADDRESS\n");
            sprintf(sessions + strlen(sessions), "==\t=============\t===========\n");
            printf("session_num outside: %d\n", session_num);
            for (int i = 0; i <= session_num; i++) {
                sprintf(sessions + strlen(sessions), "%d\t%s\t%s\t%d\n", session[i].id, session[i].protocol, session[i].address, session[i].port);
            }
            strcpy(response, sessions);
        }

        //send response
        if (send(tcp_accept, response, sizeof(response), 0) == -1)
            error("Error sending response");
    }
    close(tcp_accept);
    pthread_exit(NULL);
}


void craft_http_listener(char *request, struct http_listener *listener, int id, int listener_num) {
    char *protocol = strtok(request, " ");
    char *address = strtok(NULL, " ");
    char *port_string = strtok(NULL, "\n");

    listener->id = id;
    strcpy(listener->protocol, protocol);
    strcpy(listener->address, address);
    listener->port = atoi(port_string);
}

int start_http_listener(struct http_listener *listener) {
    //socket http
    puts("Initializing http listener...");
    int http_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (http_socket == -1)
        error("HTTP socket creation failed");

    //preparing http address
    struct sockaddr_in http_address;
    memset(&http_address, 0, sizeof(http_address));
    http_address.sin_family = AF_INET;
    http_address.sin_port = htons(listener->port);
    http_address.sin_addr.s_addr = inet_addr(listener->address);
    puts("HTTP listener initialized");

    //reuse http
    int http_reuse = 1;
    if (setsockopt(http_socket, SOL_SOCKET, SO_REUSEADDR, &http_reuse, sizeof(http_reuse)) == -1)
        error("Error reusing http address");

    if (setsockopt(http_socket, SOL_SOCKET, SO_REUSEPORT, &http_reuse, sizeof(http_reuse)) == -1)
        error("Error reusing http port");

    //bind http
    puts("Binding http listener...");
    if (bind(http_socket, (struct sockaddr *) &http_address, sizeof(http_address)) == -1)
        error("Binding HTTP failed");

    //listen http
    puts("Listening...");
    if (listen(http_socket, 0) == -1)
        error("Failed listening");

    return http_socket;
}

void *accept_http_thread(void *args) {
    struct accept_http_thread_args *targs = (struct accept_http_thread_args *)args;
    struct http_session *session = targs->session;
    struct http_listener *listener = targs->listener;
    int http_socket = targs->http_socket;
    int session_id = targs->session_id;
    int session_num = targs->session_num;
    int listener_num = targs->listener_num;

    while(1) {
        //accept http
        puts("Accepting...");
        int http_accept = accept(http_socket, NULL, NULL);
    	if (http_accept == -1)
            error("Accepting failed");
    	puts("Agent connected");
        craft_http_session(&listener[listener_num - 1], &session[session_num], session_id, session_num);
        if (session_id == MAX_SESSIONS)
            printf("Sorry no more than %s sessions allowed", MAX_SESSIONS);
        session_id++;
        session_num++;
        
        pthread_t process_http_thread_id;
        pthread_create(&process_http_thread_id, NULL, process_http_thread, (void *)&http_accept);
    }
    close(http_socket);
    pthread_exit(NULL);
}

void *process_http_thread(void *args) {
     int http_accept = *((int *)args);
}

void craft_http_session(struct http_listener *listener, struct http_session *session, int session_id, int session_num) {
    puts("inside craft");
    session->id = session_id;
    strcpy(session->protocol, listener->protocol);
    strcpy(session->address, listener->address);
    session->port = listener->port;
}
