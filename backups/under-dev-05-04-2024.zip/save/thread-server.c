#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#define IP "127.0.0.1"
#define TCP_PORT 33333
#define HTTP_PORT 80

//handle erros
void error(char *message) {
    fprintf(stderr, "%s: %s\n", message, strerror(errno));
    exit(EXIT_FAILURE);
}

void *tcp_thread(void *args);

int main() {
    //socket tcp
    puts("Initializing socket...");
    int tcp_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (tcp_socket == -1)
        error("Socket creation failed");

    //preparing address tcp
    struct sockaddr_in tcp_address;
    memset(&tcp_address, 0, sizeof(tcp_address));
    tcp_address.sin_family = AF_INET;
    tcp_address.sin_port = htons(TCP_PORT);
    tcp_address.sin_addr.s_addr = inet_addr(IP);

    int tcp_reuse = 1;
    //reuse address tcp
    if (setsockopt(tcp_socket, SOL_SOCKET, SO_REUSEADDR, &tcp_reuse, sizeof(tcp_reuse)) == -1)
        error("Error reusing tcp address");

    //reuse port tcp
    if (setsockopt(tcp_socket, SOL_SOCKET, SO_REUSEPORT, &tcp_reuse, sizeof(tcp_reuse)) == -1)
        perror("Error reusing tcp port");

    //bind tcp
    puts("Binding socket to Inferno address...");
    if (bind(tcp_socket, (struct sockaddr *) &tcp_address, sizeof(tcp_address)) == -1)
        error("Binding socket failed");

    //listen tcp
    printf("Listening to %s:%d\n", IP, TCP_PORT);
    if (listen(tcp_socket, 0) == -1)
        error("Listening failed");

    while(1) {
        //accept tcp
        puts("Accepting...");
        int tcp_accept = accept(tcp_socket, NULL, NULL);
        if (tcp_accept == -1)
            error("Accepting failed");
        puts("Client connected");

        pthread_t thread_tcp;
        pthread_create(&thread_tcp, NULL, tcp_thread, (void *)&tcp_accept);
    }
    close(tcp_socket);
}

void *tcp_thread(void *args) {
    int tcp_accept = *((int *)args);
    while(1) {
        //read request
        char request[1024];
        if (recv(tcp_accept, request, sizeof(request), 0) == -1)
            error("Error receiving request");

        //send response
        char response[1024] = "HTTP/1.0 200 OK\r\n\r\n";
        if (send(tcp_accept, response, sizeof(response), 0) == -1)
            error("Error sending response");
    }
    close(tcp_accept);
    pthread_exit(NULL);
}
